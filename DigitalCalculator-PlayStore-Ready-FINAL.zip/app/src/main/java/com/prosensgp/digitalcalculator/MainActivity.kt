package com.prosensgp.digitalcalculator

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private lateinit var adView: AdView
    private var interstitialAd: InterstitialAd? = null
    private var pendingJsCallback = false
    private lateinit var consentInformation: ConsentInformation
    private var adsInitialized = false
    private val contactPickerRequestCode = 1002

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        webView = WebView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }
        root.addView(webView)

        adView = AdView(this).apply {
            setAdSize(AdSize.BANNER)
            // Google test banner ID. Replace with your real AdMob unit ID before release.
            adUnitId = BuildConfig.ADMOB_BANNER_ID
        }
        root.addView(adView)
        setContentView(root)

        configureWebView()
        requestAdConsent()
    }


    private fun requestAdConsent() {
        consentInformation = UserMessagingPlatform.getConsentInformation(this)
        val params = ConsentRequestParameters.Builder().build()

        consentInformation.requestConsentInfoUpdate(
            this,
            params,
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(this) {
                    initializeAdsIfAllowed()
                }
            },
            {
                // If consent cannot be refreshed, use the SDK's previously stored state when allowed.
                initializeAdsIfAllowed()
            }
        )
    }

    private fun initializeAdsIfAllowed() {
        if (adsInitialized) return
        if (!consentInformation.canRequestAds()) return
        adsInitialized = true
        MobileAds.initialize(this) {}
        adView.loadAd(AdRequest.Builder().build())
        loadInterstitial()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            allowFileAccess = true
            allowContentAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            builtInZoomControls = false
            displayZoomControls = false
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                openExternalUrl(request.url.toString())

            @Deprecated("Deprecated in Android API 24")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean =
                openExternalUrl(url)
        }
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AndroidBridge(), "AndroidAd")
        webView.addJavascriptInterface(AndroidContactsBridge(), "AndroidContacts")
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun openExternalUrl(url: String): Boolean {
        if (url.startsWith("file://")) return false
        return try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun loadInterstitial() {
        InterstitialAd.load(
            this,
            // Google test interstitial ID. Replace with your real AdMob unit ID before release.
            BuildConfig.ADMOB_INTERSTITIAL_ID,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() {
                            interstitialAd = null
                            loadInterstitial()
                            notifyJsAdClosed()
                        }

                        override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                            interstitialAd = null
                            loadInterstitial()
                            notifyJsAdClosed()
                        }
                    }
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                }
            }
        )
    }

    private fun notifyJsAdClosed() {
        if (!pendingJsCallback) return
        pendingJsCallback = false
        webView.post {
            webView.evaluateJavascript("window.onNativeAdClosed && window.onNativeAdClosed();", null)
        }
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun showPrivacyOptions() {
            runOnUiThread {
                if (!::consentInformation.isInitialized) {
                    webView.evaluateJavascript("window.onNativePrivacyOptionsUnavailable && window.onNativePrivacyOptionsUnavailable('not_ready');", null)
                    return@runOnUiThread
                }
                if (consentInformation.privacyOptionsRequirementStatus ==
                    ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED) {
                    UserMessagingPlatform.showPrivacyOptionsForm(this@MainActivity) { }
                } else {
                    webView.evaluateJavascript("window.onNativePrivacyOptionsUnavailable && window.onNativePrivacyOptionsUnavailable('not_required');", null)
                }
            }
        }

        @JavascriptInterface
        fun showInterstitial() {
            runOnUiThread {
                val ad = interstitialAd
                if (ad == null) {
                    pendingJsCallback = false
                    webView.evaluateJavascript("window.onNativeAdClosed && window.onNativeAdClosed();", null)
                    loadInterstitial()
                    return@runOnUiThread
                }
                pendingJsCallback = true
                ad.show(this@MainActivity)
            }
        }
    }

    private fun startContactPicker() {
        try {
            val intent = Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)
            startActivityForResult(intent, contactPickerRequestCode)
        } catch (_: Exception) {
            webView.post {
                webView.evaluateJavascript("window.onNativeContactError && window.onNativeContactError('picker');", null)
            }
        }
    }

    private fun requestContactAccess() {
        // ACTION_PICK grants temporary access only to the contact selected by the user.
        // This avoids requesting broad READ_CONTACTS access.
        startContactPicker()
    }


    @Deprecated("Deprecated in Android API 30")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != contactPickerRequestCode || resultCode != RESULT_OK || data?.data == null) return

        val uri = data.data!!
        var name = ""
        var phone = ""
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val phoneIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                if (nameIndex >= 0) name = cursor.getString(nameIndex) ?: ""
                if (phoneIndex >= 0) phone = cursor.getString(phoneIndex) ?: ""
            }
        }
        val safeName = org.json.JSONObject.quote(name)
        val safePhone = org.json.JSONObject.quote(phone)
        webView.post {
            webView.evaluateJavascript("window.onNativeContactSelected && window.onNativeContactSelected($safeName, $safePhone);", null)
        }
    }

    inner class AndroidContactsBridge {
        @JavascriptInterface
        fun pickContact() {
            runOnUiThread { requestContactAccess() }
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        adView.destroy()
        webView.removeJavascriptInterface("AndroidAd")
        webView.removeJavascriptInterface("AndroidContacts")
        webView.destroy()
        super.onDestroy()
    }
}
