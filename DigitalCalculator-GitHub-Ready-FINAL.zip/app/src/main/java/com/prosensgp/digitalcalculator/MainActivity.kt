package com.prosensgp.digitalcalculator

import android.annotation.SuppressLint
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private lateinit var adView: AdView
    private var interstitialAd: InterstitialAd? = null
    private var pendingJsCallback = false
    private val contactsRequestCode = 1001
    private val contactPickerRequestCode = 1002

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        webView = WebView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }
        root.addView(webView)

        adView = AdView(this).apply {
            setAdSize(AdSize.BANNER)
            // Google test banner ID. Replace with your real AdMob unit ID before release.
            adUnitId = "ca-app-pub-3940256099942544/6300978111"
        }
        root.addView(adView)
        setContentView(root)

        MobileAds.initialize(this) {}
        adView.loadAd(AdRequest.Builder().build())
        loadInterstitial()
        configureWebView()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            allowFileAccess = true
            allowContentAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            builtInZoomControls = false
            displayZoomControls = false
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                openExternalUrl(request.url.toString())

            @Deprecated("Deprecated in Android API 24")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean =
                openExternalUrl(url)
        }
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AndroidBridge(), "AndroidAd")
        webView.addJavascriptInterface(AndroidContactsBridge(), "AndroidContacts")
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun openExternalUrl(url: String): Boolean {
        if (url.startsWith("file://")) return false
        return try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun loadInterstitial() {
        InterstitialAd.load(
            this,
            // Google test interstitial ID. Replace with your real AdMob unit ID before release.
            "ca-app-pub-3940256099942544/1033173712",
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() {
                            interstitialAd = null
                            loadInterstitial()
                            notifyJsAdClosed()
                        }

                        override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                            interstitialAd = null
                            loadInterstitial()
                            notifyJsAdClosed()
                        }
                    }
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                }
            }
        )
    }

    private fun notifyJsAdClosed() {
        if (!pendingJsCallback) return
        pendingJsCallback = false
        webView.post {
            webView.evaluateJavascript("window.onNativeAdClosed && window.onNativeAdClosed();", null)
        }
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun showInterstitial() {
            runOnUiThread {
                val ad = interstitialAd
                if (ad == null) {
                    pendingJsCallback = false
                    webView.evaluateJavascript("window.onNativeAdClosed && window.onNativeAdClosed();", null)
                    loadInterstitial()
                    return@runOnUiThread
                }
                pendingJsCallback = true
                ad.show(this@MainActivity)
            }
        }
    }

    private fun startContactPicker() {
        try {
            val intent = Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)
            startActivityForResult(intent, contactPickerRequestCode)
        } catch (_: Exception) {
            webView.post {
                webView.evaluateJavascript("window.onNativeContactError && window.onNativeContactError('picker');", null)
            }
        }
    }

    private fun requestContactAccess() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
            startContactPicker()
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_CONTACTS), contactsRequestCode)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == contactsRequestCode) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startContactPicker()
            } else {
                webView.post {
                    webView.evaluateJavascript("window.onNativeContactError && window.onNativeContactError('permission');", null)
                }
            }
        }
    }

    @Deprecated("Deprecated in Android API 30")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != contactPickerRequestCode || resultCode != RESULT_OK || data?.data == null) return

        val uri = data.data!!
        var name = ""
        var phone = ""
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val phoneIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                if (nameIndex >= 0) name = cursor.getString(nameIndex) ?: ""
                if (phoneIndex >= 0) phone = cursor.getString(phoneIndex) ?: ""
            }
        }
        val safeName = org.json.JSONObject.quote(name)
        val safePhone = org.json.JSONObject.quote(phone)
        webView.post {
            webView.evaluateJavascript("window.onNativeContactSelected && window.onNativeContactSelected($safeName, $safePhone);", null)
        }
    }

    inner class AndroidContactsBridge {
        @JavascriptInterface
        fun pickContact() {
            runOnUiThread { requestContactAccess() }
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        adView.destroy()
        webView.removeJavascriptInterface("AndroidAd")
        webView.removeJavascriptInterface("AndroidContacts")
        webView.destroy()
        super.onDestroy()
    }
}
