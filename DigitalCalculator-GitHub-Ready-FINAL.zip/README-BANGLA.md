# Digital Calculator — Updated Build

এই project-টি GitHub Actions এবং Play Store-এর জন্য প্রস্তুত করার উদ্দেশ্যে আপডেট করা হয়েছে।

## এই version-এ কী ঠিক করা হয়েছে

1. GitHub Actions-এ Gradle 8.13 নির্দিষ্ট করা হয়েছে।
2. Android Gradle Plugin 8.13.2 ব্যবহার করা হয়েছে।
3. Kotlin 2.3.21 ব্যবহার করা হয়েছে।
4. Play Store-এর বর্তমান target API requirement অনুযায়ী `compileSdk 36` এবং `targetSdk 36` করা হয়েছে।
5. `minSdk 24` করা হয়েছে, কারণ বর্তমান Google Mobile Ads Next-Gen SDK-এর minimum API 24; এই project-এ compatibility সহজ রাখতে Google Mobile Ads SDK 25.4.0 ব্যবহার করা হয়েছে।
6. Fake 5-second advertisement popup সরানো হয়েছে।
7. Google Mobile Ads-এর test Banner ও test Interstitial integration যোগ করা হয়েছে।
8. প্রতি 10টি ledger save-এর পরে native interstitial দেখানোর ব্যবস্থা করা হয়েছে; ad unavailable হলে save আটকে থাকবে না।
9. More Options আর বিজ্ঞাপন দেখে unlock করতে হবে না।
10. Edit করার সময় customer balance আগেভাগে নষ্ট হয়ে যাওয়ার bug ঠিক করা হয়েছে।
11. Customer list rendering-এ HTML injection/quote-related সমস্যা কমানো হয়েছে।
12. Google Fonts-এর external dependency সরানো হয়েছে, যাতে calculator UI offline-এও ঠিক থাকে।
13. WhatsApp/SMS link Android-এর external app/browser-এ খোলার ব্যবস্থা উন্নত করা হয়েছে।
14. Selected language LocalStorage-এ রাখা হয়েছে।
15. Negative number এবং gram=1000 edge case handle করা হয়েছে।
16. WebView-এর file URL security settings শক্ত করা হয়েছে।

## GitHub-এ কী করবেন

### Step 1 — পুরনো project backup
আপনার পুরনো GitHub repository-এর একটি backup রাখুন।

### Step 2 — এই ZIP-এর files repository-তে দিন
পুরনো project-এর files replace করুন। বিশেষ করে:

- `build.gradle`
- `app/build.gradle`
- `app/src/main/AndroidManifest.xml`
- `app/src/main/java/com/prosensgp/digitalcalculator/MainActivity.kt`
- `app/src/main/assets/index.html`
- `.github/workflows/build.yml`

### Step 3 — GitHub Actions চালান
GitHub → Actions → **Build Android APK** → **Run workflow**

Build সফল হলে Artifacts-এর মধ্যে:

`DigitalCalculator-debug-apk`

থাকবে।

## গুরুত্বপূর্ণ: AdMob

এই project-এ এখন Google-এর **test App ID এবং test Ad Unit IDs** রাখা আছে। এগুলো দিয়ে testing করুন। Play Store release-এর আগে অবশ্যই নিজের AdMob App ID, Banner Ad Unit ID এবং Interstitial Ad Unit ID বসাতে হবে।

## গুরুত্বপূর্ণ: Application ID

বর্তমানে:

`com.prosensgp.digitalcalculator`

ব্যবহার করা হয়েছে। যদি আপনার Play Console-এ এই package আগে থেকেই ব্যবহার করা থাকে, তাহলে package ID পরিবর্তন করবেন না। নতুন app হলে এটিকে আপনার unique package ID হিসেবে ব্যবহার করতে পারেন, যদি Play Console-এ available থাকে।

## পরের ধাপ

Build সফল হওয়ার পরে আমরা আলাদা ধাপে করব:

1. Release signing / upload key
2. Release AAB
3. নিজের AdMob IDs
4. Privacy Policy
5. Data Safety form
6. Play Store screenshots এবং description
7. Internal testing
8. Production release
9. Monetization optimization
