package com.prosensgp.digitalcalculator

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private lateinit var adView: AdView
    private var interstitialAd: InterstitialAd? = null
    private var pendingJsCallback = false
    private lateinit var consentInformation: ConsentInformation
    private var adsInitialized = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        webView = WebView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }
        root.addView(webView)

        adView = AdView(this).apply {
            setAdSize(AdSize.BANNER)
            // Google test banner ID. Replace with your real AdMob unit ID before release.
            adUnitId = BuildConfig.ADMOB_BANNER_ID
        }
        root.addView(adView)
        setContentView(root)

        configureWebView()
        requestAdConsent()
    }


    private fun requestAdConsent() {
        consentInformation = UserMessagingPlatform.getConsentInformation(this)
        val params = ConsentRequestParameters.Builder().build()

        consentInformation.requestConsentInfoUpdate(
            this,
            params,
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(this) {
                    initializeAdsIfAllowed()
                }
            },
            {
                // If consent cannot be refreshed, use the SDK's previously stored state when allowed.
                initializeAdsIfAllowed()
            }
        )
    }

    private fun initializeAdsIfAllowed() {
        if (adsInitialized) return
        if (!consentInformation.canRequestAds()) return
        adsInitialized = true
        MobileAds.initialize(this) {}
        adView.loadAd(AdRequest.Builder().build())
        loadInterstitial()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            allowFileAccess = true
            allowContentAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            builtInZoomControls = false
            displayZoomControls = false
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                openExternalUrl(request.url.toString())

            @Deprecated("Deprecated in Android API 24")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean =
                openExternalUrl(url)
        }
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AndroidBridge(), "AndroidAd")
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun openExternalUrl(url: String): Boolean {
        if (url.startsWith("file://")) return false
        return try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun loadInterstitial() {
        InterstitialAd.load(
            this,
            // Google test interstitial ID. Replace with your real AdMob unit ID before release.
            BuildConfig.ADMOB_INTERSTITIAL_ID,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() {
                            interstitialAd = null
                            loadInterstitial()
                            notifyJsAdClosed()
                        }

                        override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                            interstitialAd = null
                            loadInterstitial()
                            notifyJsAdClosed()
                        }
                    }
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                }
            }
        )
    }

    private fun notifyJsAdClosed() {
        if (!pendingJsCallback) return
        pendingJsCallback = false
        webView.post {
            webView.evaluateJavascript("window.onNativeAdClosed && window.onNativeAdClosed();", null)
        }
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun showPrivacyOptions() {
            runOnUiThread {
                if (::consentInformation.isInitialized &&
                    consentInformation.privacyOptionsRequirementStatus ==
                    ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED) {
                    UserMessagingPlatform.showPrivacyOptionsForm(this@MainActivity) { }
                }
            }
        }

        @JavascriptInterface
        fun showInterstitial() {
            runOnUiThread {
                val ad = interstitialAd
                if (ad == null) {
                    pendingJsCallback = false
                    webView.evaluateJavascript("window.onNativeAdClosed && window.onNativeAdClosed();", null)
                    loadInterstitial()
                    return@runOnUiThread
                }
                pendingJsCallback = true
                ad.show(this@MainActivity)
            }
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        adView.destroy()
        webView.removeJavascriptInterface("AndroidAd")
        webView.destroy()
        super.onDestroy()
    }
}
